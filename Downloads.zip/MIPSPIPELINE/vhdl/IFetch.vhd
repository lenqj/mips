library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity IFetch is
    Port (clk: in STD_LOGIC;
          rst : in STD_LOGIC;
          en : in STD_LOGIC;
          BranchAddress : in STD_LOGIC_VECTOR(15 downto 0);
          JumpAddress : in STD_LOGIC_VECTOR(15 downto 0);
          Jump : in STD_LOGIC;
          PCSrc : in STD_LOGIC;
          Instruction : out STD_LOGIC_VECTOR(15 downto 0);
          PCinc : out STD_LOGIC_VECTOR(15 downto 0));
end IFetch;

architecture Behavioral of IFetch is

-- Memorie ROM
type tROM is array (0 to 255) of STD_LOGIC_VECTOR (15 downto 0);
signal ROM : tROM := (

B"000_000_000_001_0_000",  --  0  add  $1, $0, $0  X"0010" 
B"001_010_000_0000101",    --  1  addi $2, $0, 5   X"2805" 
B"000_000_000_011_0_000",  --  2  add  $3, $0, $0  X"0030" 
B"000_000_000_100_0_000",  --  3  add  $4, $0, $0  X"0040" 
B"100_001_010_0000110",    --  4  beq  $2, $1, 6   X"8506" 
B"001_000_000_000000",    --   5  addi $0, $0, 0   X"1000" 
B"001_000_000_000000",    --   6  addi $0, $0, 0   X"1000" 
B"001_000_000_000000",    --   7  addi $0, $0, 0   X"1000" 
B"010_011_101_0000000",    --  8  lw   $5, 0($3)   X"4E80" 
B"001_000_000_000000",    --   9  addi $0, $0, 0   X"1000" 
B"001_000_000_000000",    --   10 addi $0, $0, 0   X"1000" 
B"000_100_100_101_0_000",  --  11  add  $4, $4, $5  X"1250"
B"001_000_000_000000",    --   12  addi $0, $0, 0   X"1000" 
B"001_000_000_000000",    --   13  addi $0, $0, 0   X"1000" 
B"011_011_101_0000000",    --  14  sw   $5, 0($3)   X"6E80" 
B"001_011_011_0000001",    --  15  addi $3, $3, 1   X"2D81" 
B"001_001_001_0000001",    --  16  addi $1, $1, 1   X"2481"
B"111_0000000000100",      --  17 j    4     	   X"E005"
B"001_000_000_000000",    --   18 addi $0, $0, 0   X"1000" 
B"000_100_010_100_0_111",  --  19 sllv $4, $4, $2   X"1147"
B"001_000_000_000000",    --   20  addi $0, $0, 0   X"1000" 
B"001_000_000_000000",    --   21  addi $0, $0, 0   X"1000" 
B"011_011_100_0000000",    --  22 sw   $4, 0($3)   X"6E00"

    others => X"0000");

signal PC : STD_LOGIC_VECTOR(15 downto 0) := (others => '0');
signal PCAux, NextAddr, AuxSgn, AuxSgn1: STD_LOGIC_VECTOR(15 downto 0);

begin

    -- Program Counter
    process(clk)
    begin
        if rising_edge(clk) then
            if rst = '1' then
                PC <= (others => '0');
            elsif en = '1' then
                PC <= NextAddr;
            end if;
        end if;
    end process;

    -- Instruction OUT
    Instruction <= ROM(conv_integer(PC(7 downto 0)));

    -- PC incremented
    PCAux <= PC + 1;
    PCinc <= PCAux;

    -- MUX Branch
    process(PCSrc, PCAux, BranchAddress)
    begin
        case PCSrc is 
            when '1' => AuxSgn <= BranchAddress;
            when others => AuxSgn <= PCAux;
        end case;
    end process;	

     -- MUX Jump
    process(Jump, AuxSgn, JumpAddress)
    begin
        case Jump is
            when '1' => NextAddr <= JumpAddress;
            when others => NextAddr <= AuxSgn;
        end case;
    end process;

end Behavioral;