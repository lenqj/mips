library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
use IEEE.numeric_std.ALL;

entity ExecutionUnit is
    Port ( PCinc : in STD_LOGIC_VECTOR(15 downto 0);
           RD1 : in STD_LOGIC_VECTOR(15 downto 0);
           RD2 : in STD_LOGIC_VECTOR(15 downto 0);
           Ext_Imm : in STD_LOGIC_VECTOR(15 downto 0);
           func : in STD_LOGIC_VECTOR(2 downto 0);
           sa : in STD_LOGIC;
           ALUSrc : in STD_LOGIC;
           ALUOp : in STD_LOGIC_VECTOR(2 downto 0);
           BranchAddress : out STD_LOGIC_VECTOR(15 downto 0);
           ALURes : out STD_LOGIC_VECTOR(15 downto 0);
           Zero : out STD_LOGIC;
           RegDst : in STD_LOGIC;
           RT : in STD_LOGIC_VECTOR (2 downto 0);
           RD : in STD_LOGIC_VECTOR (2 downto 0);
           RWA : out STD_LOGIC_VECTOR (2 downto 0));
end ExecutionUnit;

architecture Behavioral of ExecutionUnit is

signal ALUIn2 : STD_LOGIC_VECTOR(15 downto 0);
signal ALUIn1 : STD_LOGIC_VECTOR(15 downto 0);
signal ALUCtrl : STD_LOGIC_VECTOR(2 downto 0);
signal ALUResAux : STD_LOGIC_VECTOR(15 downto 0);

begin

    -- MUX for ALU input 2
    with ALUSrc select
        ALUIn2 <= RD2 when '0', 
	              Ext_Imm when '1',
	              (others => '0') when others;
			  
    -- ALU Control
    process(ALUOp, func)
    begin
        case ALUOp is
            when "000" => -- R type 
                case func is
                         when "000" => AluCtrl <= "000";
                         when "001" => AluCtrl <= "001";
                         when "010" => AluCtrl <= "011";
                         when "011" => AluCtrl <= "010";
                         when "100" => AluCtrl <= "100";
                         when "101" => AluCtrl <= "101";
                         when "110" => AluCtrl <= "110";
                         when "111" => AluCtrl <= "111";
                         when others => ALUCtrl <= (others => '0'); -- unknown
                end case;
            when "001" => AluCtrl <= "000";
            when "010" => AluCtrl <= "001";
            when "011" => AluCtrl <= "010";
            when "100" => AluCtrl <= "011";
            when others => ALUCtrl <= (others => '0'); -- unknown
        end case;
    end process;

    -- ALU
    process(ALUCtrl, RD1, AluIn2, sa, ALUResAux)
    begin
        case ALUCtrl  is
            when "000" => -- ADD
                ALUResAux <= RD1 + ALUIn2;
            when "001" =>  -- SUB
                ALUResAux <= RD1 - ALUIn2;   
                
                
                when "010" => ALUResAux <= RD1 AND ALUIn2;
                    when "011" => ALUResAux <= RD1 OR ALUIn2;
                    when "100" => 
                    case sa is
                        when '0' => ALUResAux <= ALUIn2;
                        when '1' => ALUResAux <= ALUIn2(14 downto 0)&"0";
                        when others => ALUResAux <= (others => 'X');
                    end case;
                    when "101" => 
                    case sa is
                            when '0' => ALUResAux <= ALUIn2;
                            when '1' => ALUResAux <= ALUIn2(15)&ALUIn2(15 downto 1);
                            when others => ALUResAux <= (others => 'X');
                    end case;
                    when "110" => ALUResAux <= RD1 XOR ALUIn2;
                    when "111" => 
                        case RD1 is
                                when x"0000" => ALUResAux <= ALUIn2;
                                when x"0001" => ALUResAux <= ALUIn2(14 downto 0)&"0";
                                when x"0010" => ALUResAux <= ALUIn2(13 downto 0)&"00";
                                when x"0011" => ALUResAux <= ALUIn2(12 downto 0)&"000";
                                when x"0100" => ALUResAux <= ALUIn2(11 downto 0)&"0000";
                                when x"0101" => ALUResAux <= ALUIn2(10 downto 0)&"00000";
                                when x"0110" => ALUResAux <= ALUIn2(9 downto 0)&"000000";
                                when x"0111" => ALUResAux <= ALUIn2(8 downto 0)&"0000000";
                                when x"1000" => ALUResAux <= ALUIn2(7 downto 0)&"00000000";
                                when x"1001" => ALUResAux <= ALUIn2(6 downto 0)&"000000000";
                                when x"1010" => ALUResAux <= ALUIn2(5 downto 0)&"0000000000";
                                when x"1011" => ALUResAux <= ALUIn2(4 downto 0)&"00000000000";
                                when x"1100" => ALUResAux <= ALUIn2(3 downto 0)&"000000000000";
                                when x"1101" => ALUResAux <= ALUIn2(2 downto 0)&"0000000000000";
                                when x"1110" => ALUResAux <= ALUIn2(1 downto 0)&"00000000000000";
                                when others =>  ALUResAux <= (others => '0');
                        end case;
            when others => -- unknown
                ALUResAux <= (others => '0');              
        end case;

        -- zero detector
        case ALUResAux is
            when X"0000" => Zero <= '1';
            when others => Zero <= '0';
        end case;
    
    end process;
    process(RT, RD, RegDst)
            begin
                if RegDst = '0' then
                    RWA <= RT;
                else 
                    RWA <= RD;
                end if;
    end process;

    -- ALU result
    ALURes <= ALUResAux;

    -- generate branch address
    BranchAddress <= PCinc + Ext_Imm;

end Behavioral;